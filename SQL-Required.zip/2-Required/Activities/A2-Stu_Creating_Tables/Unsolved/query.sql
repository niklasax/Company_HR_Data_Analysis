-- Create a new table

-- Insert data into the table

-- View the table data

-- Use a query to view only the cities

-- Bonus 1:
-- Create a query to view cities in Arizona

-- Bonus 2:
-- Create a query to view cities and states
-- with a population less than 100,000

-- Bonus 3:
-- Create a query to view the city in California
-- with a population of less than 100,000
