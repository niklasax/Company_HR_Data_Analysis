-- Add primary key

-- Delete and update data

-- Select averages and rename columns

-- Insert new data

-- View table
