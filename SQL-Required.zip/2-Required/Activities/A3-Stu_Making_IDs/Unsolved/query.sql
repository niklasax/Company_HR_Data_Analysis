-- Drop table if exists

-- Create new programming_languages table

-- Insert new data

-- Query the rows with the language "MySQL"

-- Drop a duplicate row

-- Add additional data

-- Update "JS" to "JavaScript"

-- Change HTML's rating to 90

-- BONUS
-- Add a "mastered" column with the boolean default of true
