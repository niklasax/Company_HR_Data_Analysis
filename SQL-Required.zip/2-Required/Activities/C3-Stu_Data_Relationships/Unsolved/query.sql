-- Query Tables

-- A join statement to query all courses taken by students
