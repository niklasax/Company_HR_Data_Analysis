-- Create a table of students

-- Create a table of courses

-- Create a junction table.

-- Insert Data into table

